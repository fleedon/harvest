// seedSpawner.js
// 種を一定間隔で生成し、落下管理するクラス

import { FallingItem } from './fallingItem.js';

export class SeedSpawner {
  constructor(canvasWidth, canvasHeight, image) {
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    this.image = image; // <img> 要素から渡す
    this.items = [];
    this.elapsed = 0;
    this.interval = 1500; // 1.5秒ごと
    this.spawnCount = 0;
    this.maxSeeds = 35;
    this.finished = false;
  }

  update(deltaTime) {
    if (this.finished) return;

    this.elapsed += deltaTime;
    if (this.elapsed >= this.interval && this.spawnCount < this.maxSeeds) {
      this.elapsed = 0;
      for (let i = 0; i < 5; i++) {
        const x = Math.random() * (this.canvasWidth - 32);
        const speed = 100 + Math.random() * 50;
        const item = new FallingItem(x, -32, speed / 1000, this.image);
        this.items.push(item);
      }
      this.spawnCount += 5;
      if (this.spawnCount >= this.maxSeeds) {
        this.finished = true;
      }
    }

    this.items.forEach(item => item.update(deltaTime));
    this.items = this.items.filter(item => !item.caught && !item.isOutOfBounds(this.canvasHeight));
  }

  draw(ctx) {
    this.items.forEach(item => item.draw(ctx));
  }

  checkCatch(catcher) {
    let caughtCount = 0;
    this.items.forEach(item => {
      if (!item.caught && item.intersects(catcher)) {
        item.markCaught();
        caughtCount++;
      }
    });
    return caughtCount;
  }

  isFinished() {
    return this.finished && this.items.length === 0;
  }

  getTotalCaught() {
    return this.spawnCount - this.items.length;
  }
}
