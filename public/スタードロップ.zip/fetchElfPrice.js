// fetchElfPrice.js
// ELF価格取得＆作物ELF換算モジュール

// 日本円基準の金属系作物価格
const metalItemJPY = {
  copper: 100,
  silver: 10000,
  gold: 100000
};

// 固定価格の石系作物（ELF）
const fixedItemELF = {
  glass: 30,
  sapphire: 1000,
  emerald: 10000,
  diamond: 300000
};

// ELF価格の取得（bitFlyer）
export async function fetchELFRate() {
  try {
    const res = await fetch("https://api.bitflyer.jp/v1/ticker?product_code=ELF_JPY");
    const data = await res.json();
    return data.ltp || 0.94; // fallback: 0.94円
  } catch (e) {
    console.warn("ELF価格取得に失敗、0.94を代用");
    return 0.94;
  }
}

// 金属系作物のELF価格を計算（小数第3位切捨て）
export function calculateMetalItemPrices(ltp) {
  const result = {};
  for (const [item, yen] of Object.entries(metalItemJPY)) {
    const value = yen / ltp;
    result[item] = Math.floor(value * 100) / 100;
  }
  return result;
}

// 全作物のELF価格（合算）を取得
export async function getAllItemELFPrices() {
  const ltp = await fetchELFRate();
  const metalPrices = calculateMetalItemPrices(ltp);

  return {
    ...metalPrices,
    ...fixedItemELF,
    elfRate: ltp // 現在のELF/JPY
  };
}
