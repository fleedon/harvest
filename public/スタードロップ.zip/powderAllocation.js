// powderAllocation.js
// 粉振り分けフェーズの統括管理クラス

import { PowderManager } from './powderManager.js';
import { Seed } from './seed.js';
import { SeedPageManager } from './seedPageManager.js';

export class PowderAllocationPhase {
  constructor(seedCount, powderAmount) {
    this.powderManager = new PowderManager(powderAmount);
    this.seeds = Array.from({ length: seedCount }, (_, i) => new Seed(i));
    this.seedPager = new SeedPageManager(this.seeds);
  }

  /**
   * 現在表示している種一覧を取得
   */
  getVisibleSeeds() {
    return this.seedPager.getCurrentPageItems();
  }

  /**
   * 粉を指定した種に1単位かける
   * @param {Seed} seed 対象の種
   * @returns {boolean} 成功したか（粉・レベル制限）
   */
  applyPowder(seed) {
    if (!this.powderManager.consume()) return false;
    return seed.addPowder();
  }

  /** ページ制御ラッパー */
  nextPage() { this.seedPager.nextPage(); }
  prevPage() { this.seedPager.prevPage(); }
  getPageCount() { return this.seedPager.getPageCount(); }
  getCurrentPageIndex() { return this.seedPager.getCurrentPageIndex(); }

  /**
   * 全種の振り分け状態をレベル配列で返す
   */
  getLevelList() {
    return this.seeds.map(seed => seed.getLevel());
  }

  /**
   * 現在の粉の残数（UI表示用）
   */
  getPowderDisplay() {
    return this.powderManager.getDisplay();
  }
}
