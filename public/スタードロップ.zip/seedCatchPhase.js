// seedCatchPhase.js
// フェーズ1：種キャッチ処理全体を制御するクラス

import { SeedSpawner } from './seedSpawner.js';
import { Catcher } from './catcher.js';

export class SeedCatchPhase {
  constructor(canvas, ctx, onComplete) {
    this.canvas = canvas;
    this.ctx = ctx;
    this.onComplete = onComplete; // 終了時コールバック

    const imgSeed = document.getElementById('img_seed');
    const imgCatcher = document.getElementById('img_master');

    this.spawner = new SeedSpawner(canvas.width, canvas.height, imgSeed);
    this.catcher = new Catcher(canvas.width, canvas.height, imgCatcher);
    this.lastTime = 0;
    this.totalCaught = 0;
    this.phaseEnded = false;

    this.canvas.addEventListener('pointerdown', e => this.handleInput(e));
    this.canvas.addEventListener('pointermove', e => this.handleInput(e));
  }

  handleInput(e) {
    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    this.catcher.moveTo(x);
  }

  update(currentTime) {
    const delta = currentTime - this.lastTime;
    this.lastTime = currentTime;

    this.catcher.update(delta);
    this.spawner.update(delta);
    this.totalCaught += this.spawner.checkCatch(this.catcher);

    if (!this.phaseEnded && this.spawner.isFinished()) {
      this.phaseEnded = true;
      setTimeout(() => this.onComplete(this.totalCaught), 1000);
    }
  }

  draw() {
    this.spawner.draw(this.ctx);
    this.catcher.draw(this.ctx);

    // カウント表示
    this.ctx.fillStyle = '#000';
    this.ctx.font = '16px sans-serif';
    this.ctx.fillText(`種GET数: ${this.totalCaught}`, 10, 30);
  }
}
