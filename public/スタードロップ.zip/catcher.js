// catcher.js
// プレイヤーが操作するキャッチャー（ザル）クラス

export class Catcher {
  constructor(canvasWidth, canvasHeight, image) {
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    this.image = image; // <img> 要素
    this.width = 48;
    this.height = 32;
    this.y = canvasHeight - 80;
    this.x = (canvasWidth - this.width) / 2;
    this.speed = 0;
    this.targetX = this.x;
  }

  /** タップ or マウスによるX座標設定 */
  moveTo(x) {
    this.targetX = x - this.width / 2;
    this.targetX = Math.max(0, Math.min(this.targetX, this.canvasWidth - this.width));
  }

  update(deltaTime) {
    const dx = this.targetX - this.x;
    this.x += dx * 0.3; // 滑らかに追従
  }

  draw(ctx) {
    if (this.image) {
      ctx.drawImage(this.image, this.x, this.y, this.width, this.height);
    } else {
      ctx.fillStyle = 'gray';
      ctx.fillRect(this.x, this.y, this.width, this.height);
    }
  }
}
