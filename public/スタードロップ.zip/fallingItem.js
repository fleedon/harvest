// fallingItem.js
// 落下アイテムの基底クラス（種・粉 共通）

export class FallingItem {
  constructor(x, y, speed, img) {
    this.x = x;
    this.y = y;
    this.speed = speed;
    this.image = img; // Imageオブジェクト
    this.width = 32;
    this.height = 32;
    this.caught = false;
  }

  update(deltaTime) {
    this.y += this.speed * deltaTime;
  }

  draw(ctx) {
    if (this.image && !this.caught) {
      ctx.drawImage(this.image, this.x, this.y, this.width, this.height);
    }
  }

  isOutOfBounds(canvasHeight) {
    return this.y > canvasHeight;
  }

  intersects(catcher) {
    return !(
      this.x + this.width < catcher.x ||
      this.x > catcher.x + catcher.width ||
      this.y + this.height < catcher.y ||
      this.y > catcher.y + catcher.height
    );
  }

  markCaught() {
    this.caught = true;
  }
}
