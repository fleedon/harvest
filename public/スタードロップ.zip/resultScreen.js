// resultScreen.js
// 抽選結果を元に、スコア／ELF換算／円換算を段階的に表示するロジック

import { getAllItemELFPrices } from './fetchElfPrice.js';

export class ResultScreenManager {
  constructor(resultSummary) {
    this.resultSummary = resultSummary; // { gold: 1, silver: 2, miss: 3, ... }
    this.prices = null; // ELF換算レート保持
    this.totalELF = 0;
    this.totalJPY = 0;
  }

  /**
   * 初期化：価格取得と合算計算
   */
  async initialize() {
    this.prices = await getAllItemELFPrices();
    this.totalELF = 0;

    for (const [key, count] of Object.entries(this.resultSummary)) {
      if (this.prices[key]) {
        this.totalELF += this.prices[key] * count;
      }
    }

    this.totalJPY = Math.floor(this.totalELF * this.prices.elfRate);
  }

  /**
   * 段階別表示用データを提供
   */
  getStepData() {
    return {
      summary: this.resultSummary, // 第1段階（取得リスト）
      elf: this.totalELF.toFixed(2), // 第2段階（ELF合計）
      jpy: this.totalJPY // 第3段階（日本円換算）
    };
  }
}
