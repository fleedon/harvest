// growthManager.js
// 抽選と結果表示を順次演出する管理クラス

import { drawMultipleResults } from './gachaRoller.js';

export class GrowthPhaseManager {
  constructor(levelList) {
    this.levelList = levelList;
    this.results = []; // [{ type: 'silver', delay: 1.2 }, ...] など
  }

  /**
   * 一括抽選を行い、演出用に遅延順を設定
   */
  rollAll() {
    const summary = drawMultipleResults(this.levelList);
    const resultArray = [];

    // サマリを展開して、演出用にリスト化
    for (const [type, count] of Object.entries(summary)) {
      for (let i = 0; i < count; i++) {
        resultArray.push(type);
      }
    }

    // ランダム順に並べ替え（より自然な演出）
    this.results = resultArray.sort(() => Math.random() - 0.5);
  }

  /**
   * 各種結果を時間差で処理していく（0.5秒ごと）
   * @param {function} onReveal - 各種表示処理（引数に type, index, total ）
   * @param {function} onFinish - 全て終わったら呼ばれるコールバック
   */
  playRevealSequence(onReveal, onFinish) {
    const total = this.results.length;
    this.results.forEach((type, i) => {
      setTimeout(() => {
        onReveal(type, i, total);
        if (i === total - 1) {
          setTimeout(() => onFinish(), 1000); // 最後は1秒ウェイト
        }
      }, i * 500);
    });
  }
}
